# Mojolicious-Plugin-RenderCGI


Rendering template with Perl code and CGI.pm funcs/subs for tags emits.

# Documentation

See [MetaCpan](https://metacpan.org/pod/Mojolicious::Plugin::RenderCGI)

# INSTALLATION

	perl Makefile.PL
	make
	make test
	make install



# LICENSE AND COPYRIGHT

Copyright (C) 2016 Михаил Че

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.
